import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import HomeScreen from './screens/HomeScreen';
import QuizScreen from './screens/QuizScreen';
import LeaderboardScreen from './screens/LeaderboardScreen';

const API_URL = 'https://3000-ig6crjctr7kb4fro0wx3r-d53b0725.us2.manus.computer/api/trpc';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'home' | 'quiz' | 'leaderboard'>('home');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Initialize user
    initializeUser();
  }, []);

  const initializeUser = async () => {
    try {
      const storedUserId = await AsyncStorage.getItem('userId');
      if (storedUserId) {
        setUserId(storedUserId);
      } else {
        // Generate a new user ID for demo purposes
        const newUserId = `user_${Date.now()}`;
        await AsyncStorage.setItem('userId', newUserId);
        setUserId(newUserId);
      }
    } catch (error) {
      console.error('Error initializing user:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStartQuiz = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentScreen('quiz');
  };

  const handleBackToHome = () => {
    setCurrentScreen('home');
    setSelectedCategory(null);
  };

  const handleViewLeaderboard = () => {
    setCurrentScreen('leaderboard');
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0066FF" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {currentScreen === 'home' && (
        <HomeScreen
          onStartQuiz={handleStartQuiz}
          onViewLeaderboard={handleViewLeaderboard}
        />
      )}
      {currentScreen === 'quiz' && selectedCategory && (
        <QuizScreen
          categoryId={selectedCategory}
          userId={userId || ''}
          onBackToHome={handleBackToHome}
        />
      )}
      {currentScreen === 'leaderboard' && (
        <LeaderboardScreen
          onBackToHome={handleBackToHome}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});
