import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import axios from 'axios';

interface LeaderboardScreenProps {
  onBackToHome: () => void;
}

interface LeaderboardEntry {
  rank: number;
  userId: string;
  score: number;
  accuracy: number;
  gamesPlayed: number;
}

const API_URL = 'https://3000-ig6crjctr7kb4fro0wx3r-d53b0725.us2.manus.computer/api/trpc';

export default function LeaderboardScreen({ onBackToHome }: LeaderboardScreenProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLeaderboard();
  }, []);

  const loadLeaderboard = async () => {
    try {
      setLoading(true);
      const response = await axios.post(`${API_URL}/trivia.getGlobalLeaderboard?input={}`, {});
      const data = response.data[0]?.result?.data || getMockLeaderboard();
      setLeaderboard(data);
    } catch (error) {
      console.error('Error loading leaderboard:', error);
      setLeaderboard(getMockLeaderboard());
    } finally {
      setLoading(false);
    }
  };

  const getMockLeaderboard = (): LeaderboardEntry[] => {
    return [
      { rank: 1, userId: 'Player1', score: 850, accuracy: 92, gamesPlayed: 15 },
      { rank: 2, userId: 'Player2', score: 720, accuracy: 88, gamesPlayed: 12 },
      { rank: 3, userId: 'Player3', score: 650, accuracy: 85, gamesPlayed: 10 },
      { rank: 4, userId: 'Player4', score: 580, accuracy: 80, gamesPlayed: 8 },
      { rank: 5, userId: 'Player5', score: 520, accuracy: 78, gamesPlayed: 7 },
    ];
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBackToHome}>
          <Text style={styles.backButton}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>🏆 Global Leaderboard</Text>
        <View style={{ width: 50 }} />
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0066FF" />
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.leaderboardContainer}>
          {leaderboard.map((entry, index) => (
            <View key={index} style={styles.leaderboardRow}>
              <View style={styles.rankContainer}>
                <Text style={styles.rankText}>{entry.rank}</Text>
              </View>
              <View style={styles.playerInfo}>
                <Text style={styles.playerName}>{entry.userId}</Text>
                <Text style={styles.playerStats}>
                  {entry.gamesPlayed} games • {entry.accuracy}% accuracy
                </Text>
              </View>
              <View style={styles.scoreContainer}>
                <Text style={styles.scoreText}>{entry.score}</Text>
              </View>
            </View>
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF9E6',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  backButton: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#0066FF',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#000',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  leaderboardContainer: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  leaderboardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#FFCC00',
  },
  rankContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0066FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  rankText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  playerInfo: {
    flex: 1,
  },
  playerName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
  playerStats: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  scoreContainer: {
    backgroundColor: '#FFCC00',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  scoreText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
});
