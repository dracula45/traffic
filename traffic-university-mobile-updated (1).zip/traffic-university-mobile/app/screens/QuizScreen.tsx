import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import axios from 'axios';

interface QuizScreenProps {
  categoryId: string;
  userId: string;
  onBackToHome: () => void;
}

interface Question {
  id: number;
  question: string;
  answers: Array<{
    option: string;
    text: string;
    correct: boolean;
  }>;
  explanation: string;
}

const API_URL = 'https://3000-ig6crjctr7kb4fro0wx3r-d53b0725.us2.manus.computer/api/trpc';

export default function QuizScreen({ categoryId, userId, onBackToHome }: QuizScreenProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [loading, setLoading] = useState(true);
  const [sessionId, setSessionId] = useState<string | null>(null);

  useEffect(() => {
    loadQuestions();
  }, [categoryId]);

  useEffect(() => {
    if (!showExplanation && timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    }
    if (timeLeft === 0 && !selectedAnswer) {
      handleTimeUp();
    }
  }, [timeLeft, showExplanation, selectedAnswer]);

  const loadQuestions = async () => {
    try {
      setLoading(true);
      const response = await axios.post(
        `${API_URL}/trivia.getQuestions?input={"categoryId":"${categoryId}"}`,
        {}
      );
      const data = response.data[0]?.result?.data || [];
      setQuestions(data);
    } catch (error) {
      console.error('Error loading questions:', error);
      // Fallback to mock data
      setQuestions(getMockQuestions());
    } finally {
      setLoading(false);
    }
  };

  const getMockQuestions = (): Question[] => {
    return [
      {
        id: 1,
        question: 'What is the legal age to drive a car in Rwanda?',
        answers: [
          { option: 'a', text: '16 years old', correct: false },
          { option: 'b', text: '18 years old', correct: true },
          { option: 'c', text: '21 years old', correct: false },
          { option: 'd', text: '25 years old', correct: false },
        ],
        explanation: 'In Rwanda, the legal age to drive a car is 18 years old.',
      },
      {
        id: 2,
        question: 'Is it mandatory to wear a seatbelt while driving in Rwanda?',
        answers: [
          { option: 'a', text: 'Yes, always', correct: true },
          { option: 'b', text: 'Only on highways', correct: false },
          { option: 'c', text: 'No, it is optional', correct: false },
          { option: 'd', text: 'Only for passengers', correct: false },
        ],
        explanation: 'Wearing a seatbelt is mandatory for all occupants of a vehicle in Rwanda.',
      },
      {
        id: 3,
        question: 'What should you do when you see a red traffic light?',
        answers: [
          { option: 'a', text: 'Continue driving', correct: false },
          { option: 'b', text: 'Stop completely', correct: true },
          { option: 'c', text: 'Slow down and proceed', correct: false },
          { option: 'd', text: 'Honk and continue', correct: false },
        ],
        explanation: 'A red traffic light means you must stop completely and wait for the green light.',
      },
    ];
  };

  const handleTimeUp = () => {
    setSelectedAnswer('timeout');
    setShowExplanation(true);
  };

  const handleAnswerSelect = (option: string) => {
    if (selectedAnswer) return;

    setSelectedAnswer(option);
    const isCorrect = questions[currentQuestionIndex].answers.find(
      (a) => a.option === option
    )?.correct;

    if (isCorrect) {
      const points = Math.max(10, Math.floor(timeLeft / 3));
      const streakBonus = Math.floor(streak / 2) * 5;
      setScore(score + points + streakBonus);
      setStreak(streak + 1);
    } else {
      setStreak(0);
    }

    setShowExplanation(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
      setTimeLeft(30);
    } else {
      // Quiz finished
      onBackToHome();
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#0066FF" />
          <Text style={styles.loadingText}>Loading questions...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (questions.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>No questions available</Text>
          <TouchableOpacity style={styles.backButton} onPress={onBackToHome}>
            <Text style={styles.backButtonText}>Back to Home</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = `${currentQuestionIndex + 1}/${questions.length}`;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Text style={styles.progressText}>{progress}</Text>
            <View style={styles.timerContainer}>
              <Text style={styles.timerText}>{timeLeft}s</Text>
            </View>
          </View>
          <View style={styles.headerRight}>
            <Text style={styles.scoreText}>Score: {score}</Text>
            {streak > 0 && <Text style={styles.streakText}>🔥 Streak: {streak}</Text>}
          </View>
        </View>

        {/* Question */}
        <View style={styles.questionContainer}>
          <Text style={styles.questionText}>{currentQuestion.question}</Text>
        </View>

        {/* Answers */}
        <View style={styles.answersContainer}>
          {currentQuestion.answers.map((answer) => {
            let buttonStyle = styles.answerButton;
            let textStyle = styles.answerButtonText;

            if (selectedAnswer) {
              if (answer.correct) {
                buttonStyle = [styles.answerButton, styles.correctAnswer];
                textStyle = [styles.answerButtonText, styles.correctAnswerText];
              } else if (selectedAnswer === answer.option && !answer.correct) {
                buttonStyle = [styles.answerButton, styles.wrongAnswer];
                textStyle = [styles.answerButtonText, styles.wrongAnswerText];
              }
            }

            return (
              <TouchableOpacity
                key={answer.option}
                style={buttonStyle}
                onPress={() => handleAnswerSelect(answer.option)}
                disabled={selectedAnswer !== null}
              >
                <Text style={textStyle}>
                  {answer.option.toUpperCase()}. {answer.text}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Explanation */}
        {showExplanation && (
          <View style={styles.explanationContainer}>
            <Text style={styles.explanationTitle}>Explanation</Text>
            <Text style={styles.explanationText}>{currentQuestion.explanation}</Text>
            <TouchableOpacity
              style={styles.nextButton}
              onPress={handleNextQuestion}
            >
              <Text style={styles.nextButtonText}>
                {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
              </Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF9E6',
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    color: '#666',
    marginBottom: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  headerRight: {
    alignItems: 'flex-end',
  },
  progressText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
  timerContainer: {
    backgroundColor: '#FFCC00',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  timerText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
  scoreText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#000',
  },
  streakText: {
    fontSize: 12,
    color: '#FF6B6B',
    marginTop: 4,
  },
  questionContainer: {
    backgroundColor: '#0066FF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  questionText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  answersContainer: {
    marginBottom: 20,
  },
  answerButton: {
    backgroundColor: '#fff',
    borderWidth: 2,
    borderColor: '#FFCC00',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
  },
  answerButtonText: {
    fontSize: 14,
    color: '#000',
  },
  correctAnswer: {
    backgroundColor: '#00CC66',
    borderColor: '#00CC66',
  },
  correctAnswerText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  wrongAnswer: {
    backgroundColor: '#FF6B6B',
    borderColor: '#FF6B6B',
  },
  wrongAnswerText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  explanationContainer: {
    backgroundColor: '#E6F4FE',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  explanationTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#0066FF',
    marginBottom: 8,
  },
  explanationText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 16,
    lineHeight: 20,
  },
  nextButton: {
    backgroundColor: '#00CC66',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  nextButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  backButton: {
    backgroundColor: '#0066FF',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
  },
  backButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
