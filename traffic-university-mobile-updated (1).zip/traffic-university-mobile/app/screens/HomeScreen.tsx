import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Image,
} from 'react-native';

interface HomeScreenProps {
  onStartQuiz: (categoryId: string) => void;
  onViewLeaderboard: () => void;
}

const categories = [
  {
    id: 'amategeko_yumuhanda',
    name: 'Amategeko yumuhanda',
    description: 'Traffic Laws & Regulations',
    icon: 'ℹ️',
  },
  {
    id: 'ibyapa',
    name: 'Ibyapa',
    description: 'Traffic Signs',
    icon: '⚡',
  },
  {
    id: 'imivuduko',
    name: 'Imivuduko',
    description: 'Speed Limits',
    icon: '🚗',
  },
];

export default function HomeScreen({ onStartQuiz, onViewLeaderboard }: HomeScreenProps) {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>🚗 Traffic University</Text>
          <Text style={styles.subtitle}>Rwanda Traffic Trivia</Text>
        </View>

        {/* Category Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose Your Challenge</Text>
          <Text style={styles.sectionDescription}>
            Select a category to start playing and test your knowledge!
          </Text>

          {categories.map((category) => (
            <TouchableOpacity
              key={category.id}
              style={styles.categoryCard}
              onPress={() => onStartQuiz(category.id)}
            >
              <View style={styles.categoryHeader}>
                <Text style={styles.categoryIcon}>{category.icon}</Text>
                <View style={styles.categoryInfo}>
                  <Text style={styles.categoryName}>{category.name}</Text>
                  <Text style={styles.categoryDescription}>{category.description}</Text>
                </View>
              </View>
              <TouchableOpacity
                style={styles.startButton}
                onPress={() => onStartQuiz(category.id)}
              >
                <Text style={styles.startButtonText}>Start Quiz</Text>
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>

        {/* Leaderboard Section */}
        <View style={styles.section}>
          <TouchableOpacity
            style={styles.leaderboardCard}
            onPress={onViewLeaderboard}
          >
            <Text style={styles.leaderboardIcon}>🏆</Text>
            <Text style={styles.leaderboardTitle}>Global Leaderboard</Text>
            <Text style={styles.leaderboardDescription}>
              See how you rank against all players worldwide
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF9E6',
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  header: {
    backgroundColor: 'linear-gradient(90deg, #0066FF 0%, #FFCC00 50%, #00CC66 100%)',
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderRadius: 12,
    marginBottom: 24,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#fff',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 8,
  },
  sectionDescription: {
    fontSize: 14,
    color: '#666',
    marginBottom: 16,
  },
  categoryCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 2,
    borderColor: '#FFCC00',
    elevation: 2,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryIcon: {
    fontSize: 32,
    marginRight: 12,
  },
  categoryInfo: {
    flex: 1,
  },
  categoryName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#000',
  },
  categoryDescription: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  startButton: {
    backgroundColor: '#0066FF',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  startButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  leaderboardCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#FFCC00',
    alignItems: 'center',
    elevation: 2,
  },
  leaderboardIcon: {
    fontSize: 40,
    marginBottom: 8,
  },
  leaderboardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginBottom: 4,
  },
  leaderboardDescription: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
});
