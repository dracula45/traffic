# Traffic University Mobile - Quick Start Guide

## What You Have

A complete React Native Expo app for Android that mirrors your web Traffic University trivia game. The app includes:

- ✅ Category selection screen (Amategeko yumuhanda, Imivuduko, Ibyapa)
- ✅ Timed quiz game with 30-second countdown
- ✅ Streak and score system
- ✅ Answer explanations
- ✅ Global leaderboard
- ✅ Arcade-inspired UI with electric blue, yellow, and green colors

## Project Structure

```
traffic-university-mobile/
├── app/
│   ├── index.tsx                    # Main app entry
│   └── screens/
│       ├── HomeScreen.tsx           # Category selection
│       ├── QuizScreen.tsx           # Quiz game logic
│       └── LeaderboardScreen.tsx    # Leaderboard display
├── app.json                         # App configuration
├── package.json                     # Dependencies
├── ANDROID_BUILD_GUIDE.md          # Build instructions
└── QUICK_START.md                  # This file
```

## Development Setup

### 1. Install Dependencies
```bash
cd traffic-university-mobile
npm install
```

### 2. Start Development Server
```bash
npm start
# or
expo start
```

### 3. Test on Device
- Scan QR code with Expo Go app (Android/iOS)
- Or press 'a' to open Android emulator
- Or press 'i' to open iOS simulator (macOS only)

## Making Changes

### Edit Home Screen
File: `app/screens/HomeScreen.tsx`
- Change category names
- Modify colors and styling
- Update button text

### Edit Quiz Game
File: `app/screens/QuizScreen.tsx`
- Change timer duration (currently 30 seconds)
- Modify scoring logic
- Update UI colors

### Edit Leaderboard
File: `app/screens/LeaderboardScreen.tsx`
- Customize leaderboard display
- Change ranking logic
- Update styling

### Change App Name
Edit `app.json`:
```json
{
  "expo": {
    "name": "Your App Name"
  }
}
```

### Change API Endpoint
Edit `app/index.tsx` and screen files:
```typescript
const API_URL = 'your-api-url-here/api/trpc';
```

## Building for Android

### Quick Build (Testing)
```bash
eas build --platform android --type apk
```

### Production Build (Play Store)
```bash
eas build --platform android --type app-bundle
```

See `ANDROID_BUILD_GUIDE.md` for detailed instructions.

## Customization Ideas

1. **Add More Questions** - Update the mock questions in QuizScreen.tsx
2. **Change Colors** - Modify StyleSheet colors in each screen
3. **Add Sound Effects** - Use `react-native-sound`
4. **Add Animations** - Use `react-native-reanimated`
5. **Add Difficulty Levels** - Modify quiz logic to support Easy/Medium/Hard
6. **Add User Profiles** - Create a new ProfileScreen component
7. **Add Achievements** - Track badges and milestones
8. **Add Multiplayer** - Implement real-time competition

## Testing Checklist

- [ ] App launches without errors
- [ ] Category selection works
- [ ] Quiz timer counts down
- [ ] Correct answers highlight green
- [ ] Wrong answers highlight red
- [ ] Score increases on correct answers
- [ ] Streak resets on wrong answers
- [ ] Explanation displays after answer
- [ ] Next button proceeds to next question
- [ ] Leaderboard displays top players

## Publishing to Play Store

1. Create Google Play Developer account ($25 one-time fee)
2. Generate signing key
3. Build production AAB
4. Upload to Play Console
5. Fill in app details and screenshots
6. Submit for review

See `ANDROID_BUILD_GUIDE.md` for step-by-step instructions.

## Troubleshooting

### App won't start
- Run `npm install` to ensure all dependencies are installed
- Clear cache: `npm cache clean --force`
- Delete node_modules and reinstall: `rm -rf node_modules && npm install`

### Can't connect to API
- Verify API URL is correct in code
- Check network connectivity
- Ensure API server is running

### Build fails
- Check Expo login: `eas whoami`
- Verify internet connection
- Check app.json for syntax errors

## Resources

- Expo Documentation: https://docs.expo.dev
- React Native Docs: https://reactnative.dev
- EAS Build: https://docs.expo.dev/build/
- Google Play Console: https://play.google.com/console

## Next Steps

1. **Test the app** - Run it on your device or emulator
2. **Customize** - Make it your own with colors, questions, and features
3. **Build APK** - Follow the Android Build Guide
4. **Release** - Submit to Google Play Store

Good luck! 🚀
