# Android APK Signing Setup Guide

## Creating Your Keystore File

Your keystore file is essential for signing APKs for Google Play Console. Follow these steps carefully.

### Step 1: Generate Keystore File

**On Windows (Command Prompt or PowerShell):**
```cmd
keytool -genkey -v -keystore traffic-university.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias traffic-university
```

**On Mac/Linux (Terminal):**
```bash
keytool -genkey -v -keystore traffic-university.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias traffic-university
```

### Step 2: Answer the Prompts

When prompted, enter the following information:

```
Enter keystore password: [CREATE A STRONG PASSWORD - SAVE THIS!]
Re-enter new password: [REPEAT PASSWORD]
What is your first and last name?
  [Your Name]
What is the name of your organizational unit?
  [Traffic University]
What is the name of your organization?
  [Traffic University]
What is the name of your City or Locality?
  [Kigali]
What is the name of your State or Province?
  [Kigali]
What is the two-letter country code for this unit?
  [RW]
Is CN=Your Name, OU=Traffic University, O=Traffic University, L=Kigali, ST=Kigali, C=RW correct?
  [yes]
Enter key password for <traffic-university>
  [PRESS ENTER to use same password as keystore]
```

### Step 3: Secure Your Keystore

The `traffic-university.keystore` file is now created. **Important:**
- Store it in a safe location
- Back it up to cloud storage or external drive
- Never commit it to version control
- Never share it with anyone

---

## Step 4: Create Signing Configuration

Create a file named `android/app/signing.properties` with your keystore information:

```properties
MYAPP_UPLOAD_STORE_FILE=traffic-university.keystore
MYAPP_UPLOAD_KEY_ALIAS=traffic-university
MYAPP_UPLOAD_STORE_PASSWORD=YOUR_KEYSTORE_PASSWORD_HERE
MYAPP_UPLOAD_KEY_PASSWORD=YOUR_KEY_PASSWORD_HERE
```

**Replace:**
- `YOUR_KEYSTORE_PASSWORD_HERE` with the password you created
- `YOUR_KEY_PASSWORD_HERE` with the key password (usually same as keystore password)

---

## Step 5: Update build.gradle

Edit `android/app/build.gradle` and add this section in the `android` block:

```gradle
android {
    ...
    
    signingConfigs {
        release {
            if (project.hasProperty('MYAPP_UPLOAD_STORE_FILE')) {
                storeFile file(MYAPP_UPLOAD_STORE_FILE)
                storePassword MYAPP_UPLOAD_STORE_PASSWORD
                keyAlias MYAPP_UPLOAD_KEY_ALIAS
                keyPassword MYAPP_UPLOAD_KEY_PASSWORD
            }
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

---

## Step 6: Verify Keystore Information

To view your keystore details:

```bash
keytool -list -v -keystore traffic-university.keystore
```

You'll need to enter your keystore password. This shows:
- Certificate fingerprints (SHA-1, SHA-256)
- Validity dates
- Key alias information

---

## Troubleshooting

### "keytool: command not found"
- **Solution:** Java is not installed or not in PATH
- Install Java Development Kit (JDK) from [oracle.com](https://www.oracle.com/java/technologies/downloads/)

### "Invalid keystore format"
- **Solution:** Keystore file is corrupted
- Delete and regenerate using the steps above

### "Keystore was tampered with, or password was incorrect"
- **Solution:** Wrong password entered
- Make sure you're using the exact password you created

---

## Backup Strategy

**Create backups of:**
1. `traffic-university.keystore` file
2. Your keystore password (store securely)
3. Your key alias name
4. `signing.properties` file (without passwords for reference)

**Backup locations:**
- Cloud storage (Google Drive, Dropbox, OneDrive)
- External hard drive
- Password manager (for passwords)

---

## Important Reminders

⚠️ **CRITICAL:** 
- You MUST use the same keystore for all future app updates
- Losing your keystore means you cannot update your app on Google Play
- Google Play ties your app to your keystore's certificate
- Keep your passwords safe and secure

✅ **Best Practices:**
- Use a strong, unique password
- Store keystore in a secure location
- Back up regularly
- Document your keystore information
- Never share keystore or passwords

---

## Next Steps

1. Generate your keystore file
2. Create `signing.properties` file
3. Update `build.gradle` with signing configuration
4. Build your release APK
5. Upload to Google Play Console

For more information, see `GOOGLE_PLAY_CONSOLE_GUIDE.md`
