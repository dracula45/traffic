# Traffic University Android App - Complete Setup & Deployment Guide

## Overview

This is a complete React Native Expo app built for Android. It's fully editable, customizable, and ready to be built and released on Google Play Store.

**What's Included:**
- ✅ Complete React Native Expo project
- ✅ Three quiz categories (Amategeko yumuhanda, Imivuduko, Ibyapa)
- ✅ Timed quiz game with 30-second countdown
- ✅ Streak and scoring system
- ✅ Global leaderboard
- ✅ Arcade-inspired UI (electric blue, yellow, green)
- ✅ Ready for Play Store submission

---

## Part 1: Local Development Setup

### Step 1: Install Required Tools

#### On Windows/Mac/Linux:

1. **Install Node.js** (v16 or higher)
   - Download from: https://nodejs.org/
   - Verify installation: `node --version`

2. **Install Expo CLI**
   ```bash
   npm install -g expo-cli
   ```

3. **Install EAS CLI** (for building APK)
   ```bash
   npm install -g eas-cli
   ```

### Step 2: Extract and Setup Project

```bash
# Extract the project
unzip traffic-university-mobile.zip
cd traffic-university-mobile

# Install dependencies
npm install
```

### Step 3: Start Development Server

```bash
npm start
# or
expo start
```

You'll see a QR code in the terminal.

### Step 4: Test on Your Device

**Option A: Using Expo Go App (Easiest)**
1. Download "Expo Go" from Google Play Store
2. Scan the QR code from terminal
3. App loads on your phone

**Option B: Using Android Emulator**
1. Install Android Studio: https://developer.android.com/studio
2. Create a virtual device
3. Press 'a' in terminal to open emulator
4. App runs in emulator

---

## Part 2: Customizing the App

### Change App Name

Edit `app.json`:
```json
{
  "expo": {
    "name": "My Traffic Quiz"
  }
}
```

### Change Colors

Edit color values in screen files:

**HomeScreen.tsx:**
```typescript
// Change primary color
backgroundColor: '#0066FF'  // Electric blue

// Change accent color
borderColor: '#FFCC00'      // Sunshine yellow

// Change success color
backgroundColor: '#00CC66'  // Green
```

### Add More Questions

Edit `app/screens/QuizScreen.tsx`:

```typescript
const getMockQuestions = (): Question[] => {
  return [
    {
      id: 1,
      question: 'Your question here?',
      answers: [
        { option: 'a', text: 'Option A', correct: true },
        { option: 'b', text: 'Option B', correct: false },
        { option: 'c', text: 'Option C', correct: false },
        { option: 'd', text: 'Option D', correct: false },
      ],
      explanation: 'Explanation for the answer',
    },
    // Add more questions...
  ];
};
```

### Change Quiz Timer

Edit `app/screens/QuizScreen.tsx`:

```typescript
// Change from 30 to your desired seconds
const [timeLeft, setTimeLeft] = useState(30);
```

### Customize Category Names

Edit `app/screens/HomeScreen.tsx`:

```typescript
const categories = [
  {
    id: 'category_id',
    name: 'Your Category Name',
    description: 'Category Description',
    icon: '🎯',  // Change emoji
  },
  // ...
];
```

---

## Part 3: Building APK for Testing

### Quick Test Build

```bash
eas build --platform android --type apk
```

This creates an APK you can install on any Android device.

**Steps:**
1. Run the command above
2. Wait for build to complete (5-10 minutes)
3. Download APK link from terminal
4. Transfer to Android device
5. Enable "Unknown Sources" in Settings > Security
6. Open APK and install

### Test on Device

1. Download APK to your phone
2. Open file manager
3. Tap the APK file
4. Tap "Install"
5. Launch app from app drawer

---

## Part 4: Preparing for Google Play Store

### Step 1: Create Developer Account

1. Go to https://play.google.com/console
2. Pay $25 one-time registration fee
3. Complete your developer profile

### Step 2: Generate Signing Key

This key signs your app. Keep it safe!

```bash
keytool -genkey -v -keystore traffic-university-key.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias traffic-university
```

**When prompted:**
- Keystore password: Create a strong password
- Key password: Same as keystore password
- First and Last Name: Your name
- Organizational Unit: Your company/name
- Organization: Your company
- City: Your city
- State: Your state
- Country: Your country code (e.g., RW for Rwanda)

**Save this keystore file securely!** You'll need it for all future updates.

### Step 3: Configure EAS with Signing Key

```bash
eas credentials
```

Follow the prompts to upload your keystore file.

### Step 4: Update App Version

Edit `app.json`:

```json
{
  "expo": {
    "version": "1.0.0",
    "android": {
      "versionCode": 1,
      "package": "com.trafficuniversity.app"
    }
  }
}
```

### Step 5: Build Production Bundle

```bash
eas build --platform android --type app-bundle
```

This creates an AAB file (Android App Bundle) required for Play Store.

Wait for the build to complete and download the AAB file.

---

## Part 5: Submitting to Google Play Store

### Step 1: Create App Listing

1. Go to Play Console
2. Click "Create app"
3. Fill in:
   - App name: "Traffic University"
   - Default language: English
   - App category: Games > Trivia
   - Content rating: Complete questionnaire

### Step 2: Add App Details

1. **Description:**
   ```
   Test your knowledge of Rwanda traffic laws, signs, and speed limits!
   
   Features:
   - Three quiz categories
   - Timed questions
   - Streak bonuses
   - Global leaderboard
   - Fun arcade-style gameplay
   ```

2. **Screenshots:** (minimum 2)
   - Home screen
   - Quiz screen
   - Leaderboard screen

3. **Icon:** 512x512 PNG image

4. **Feature Graphic:** 1024x500 PNG image

### Step 3: Set Pricing

- Select "Free"

### Step 4: Content Rating

Complete the questionnaire:
- Violence: None
- Sexual content: None
- Profanity: None
- Alcohol/Tobacco: None

### Step 5: Upload Build

1. Go to "Release" > "Production"
2. Click "Create new release"
3. Upload the AAB file from EAS Build
4. Add release notes: "Initial release"
5. Review and publish

---

## Part 6: Updating Your App

When you make changes and want to release an update:

### Step 1: Update Version

Edit `app.json`:

```json
{
  "version": "1.0.1",
  "android": {
    "versionCode": 2
  }
}
```

### Step 2: Build New AAB

```bash
eas build --platform android --type app-bundle
```

### Step 3: Upload to Play Store

1. Go to Play Console
2. Click "Create new release"
3. Upload new AAB
4. Add release notes
5. Publish

---

## Troubleshooting

### Build Fails

**Solution:**
```bash
# Clear cache
npm cache clean --force

# Reinstall dependencies
rm -rf node_modules
npm install

# Try building again
eas build --platform android --type app-bundle
```

### APK Won't Install

**Check:**
- Device has Android 5.0 or higher
- Enough storage space
- "Unknown Sources" is enabled

### App Crashes on Launch

**Check:**
- Internet connection is working
- API endpoint is correct
- No syntax errors in code

### Can't Login to EAS

```bash
# Logout and login again
eas logout
eas login
```

---

## Project File Structure

```
traffic-university-mobile/
├── app/
│   ├── index.tsx                    # Main app entry
│   └── screens/
│       ├── HomeScreen.tsx           # Category selection
│       ├── QuizScreen.tsx           # Quiz game
│       └── LeaderboardScreen.tsx    # Leaderboard
├── assets/
│   └── images/                      # App icons and images
├── app.json                         # App configuration
├── package.json                     # Dependencies
├── eas.json                         # EAS build config
├── QUICK_START.md                   # Quick reference
├── ANDROID_BUILD_GUIDE.md           # Build guide
└── SETUP_AND_DEPLOYMENT.md          # This file
```

---

## Important Files to Know

| File | Purpose |
|------|---------|
| `app.json` | App name, version, package name, icons |
| `app/index.tsx` | Main app logic and navigation |
| `app/screens/HomeScreen.tsx` | Category selection UI |
| `app/screens/QuizScreen.tsx` | Quiz game logic |
| `app/screens/LeaderboardScreen.tsx` | Leaderboard display |
| `package.json` | Dependencies and scripts |

---

## Useful Commands

```bash
# Start development server
npm start

# Build APK for testing
eas build --platform android --type apk

# Build AAB for Play Store
eas build --platform android --type app-bundle

# Check Expo login status
eas whoami

# Logout from Expo
eas logout

# Clear cache
npm cache clean --force

# Install dependencies
npm install
```

---

## Support Resources

- **Expo Documentation:** https://docs.expo.dev
- **React Native Docs:** https://reactnative.dev
- **EAS Build Guide:** https://docs.expo.dev/build/
- **Google Play Console:** https://play.google.com/console
- **Android Studio:** https://developer.android.com/studio

---

## Next Steps

1. ✅ Extract the project
2. ✅ Run `npm install`
3. ✅ Test locally with `npm start`
4. ✅ Customize colors, questions, and content
5. ✅ Build APK with `eas build --platform android --type apk`
6. ✅ Test on Android device
7. ✅ Create Google Play Developer account
8. ✅ Generate signing key
9. ✅ Build production AAB
10. ✅ Submit to Play Store

---

## Questions?

Refer to the included guides:
- `QUICK_START.md` - Quick reference
- `ANDROID_BUILD_GUIDE.md` - Detailed build instructions
- Official Expo docs: https://docs.expo.dev

Good luck with your app! 🚀
