# Traffic University - Android App

A complete React Native Expo application for Rwanda traffic trivia. Test your knowledge of traffic laws, signs, and speed limits with our arcade-inspired quiz game!

## Features

**Interactive Quiz Game**
- 30-second timed questions
- Multiple-choice answers
- Instant feedback with explanations
- Streak and combo bonus system

**Leaderboards**
- Global rankings
- Track your progress

**Arcade-Inspired Design**
- Electric blue, sunshine yellow, and green colors
- Smooth animations
- Responsive UI

## Quick Start

### Prerequisites
- Node.js 16+
- npm or yarn
- Expo CLI: `npm install -g expo-cli`

### Installation

```bash
# Extract the project
unzip traffic-university-mobile.zip
cd traffic-university-mobile

# Install dependencies
npm install

# Start development server
npm start
```

### Testing

**On Your Phone:**
1. Download Expo Go from Google Play Store
2. Scan the QR code from terminal
3. App loads instantly

**On Emulator:**
1. Press 'a' in terminal
2. Android emulator opens
3. App runs in emulator

## Documentation

- `QUICK_START.md` - Quick reference guide
- `ANDROID_BUILD_GUIDE.md` - Detailed build instructions
- `SETUP_AND_DEPLOYMENT.md` - Complete setup and deployment guide

## Building for Android

```bash
# Test build (APK)
eas build --platform android --type apk

# Production build (Play Store)
eas build --platform android --type app-bundle
```

See `ANDROID_BUILD_GUIDE.md` for detailed instructions.

## Project Structure

```
traffic-university-mobile/
├── app/
│   ├── index.tsx              # Main app entry
│   └── screens/
│       ├── HomeScreen.tsx     # Category selection
│       ├── QuizScreen.tsx     # Quiz game
│       └── LeaderboardScreen.tsx  # Leaderboard
├── assets/                    # Icons and images
├── app.json                   # App configuration
├── package.json               # Dependencies
└── Documentation files
```

## Resources

- Expo Documentation: https://docs.expo.dev
- React Native Docs: https://reactnative.dev
- Google Play Console: https://play.google.com/console

## Next Steps

1. Extract the project
2. Run `npm install`
3. Test locally with `npm start`
4. Customize colors and questions
5. Build APK with `eas build --platform android --type apk`
6. Submit to Play Store

See `SETUP_AND_DEPLOYMENT.md` for complete instructions.
