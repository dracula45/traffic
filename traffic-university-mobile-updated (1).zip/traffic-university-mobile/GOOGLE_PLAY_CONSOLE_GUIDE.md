# Traffic University - Google Play Console Deployment Guide

## Complete Step-by-Step Guide to Build and Release Your Android App

This guide will walk you through the entire process of building your React Native Expo app and releasing it on Google Play Console.

---

## Prerequisites

Before starting, ensure you have:
- Node.js 16+ installed
- npm or yarn package manager
- Android Studio installed (for emulator testing)
- Google Play Developer Account ($25 one-time fee)
- A Google account for Google Play Console

---

## Part 1: Local Setup and Testing

### Step 1: Install Dependencies

```bash
cd traffic-university-mobile
npm install
# or
yarn install
```

### Step 2: Test on Android Emulator

```bash
# Start the Expo development server
npm start

# In another terminal, run on Android emulator
npm run android
```

This will launch your app on the Android emulator. Test all features:
- Quiz gameplay
- Category selection
- Leaderboard
- Language toggle (English/Kinyarwanda)
- Admin panel

---

## Part 2: Build APK for Google Play Console

### Step 1: Create a Keystore File

A keystore file is required to sign your APK. This is a one-time process.

**On Windows/Mac/Linux:**

```bash
# Navigate to your project directory
cd traffic-university-mobile

# Generate keystore (you'll be prompted for passwords and information)
keytool -genkey -v -keystore traffic-university.keystore -keyalg RSA -keysize 2048 -validity 10000 -alias traffic-university

# You'll be asked for:
# - Keystore password (remember this!)
# - Key password (can be same as keystore)
# - Your name
# - Organization name: Traffic University
# - City/locality: Kigali
# - State: Kigali
# - Country code: RW
```

**Important:** Save this keystore file securely. You'll need it for all future updates!

### Step 2: Create Signing Configuration

Create a file `android/app/signing.properties`:

```properties
MYAPP_UPLOAD_STORE_FILE=traffic-university.keystore
MYAPP_UPLOAD_KEY_ALIAS=traffic-university
MYAPP_UPLOAD_STORE_PASSWORD=YOUR_KEYSTORE_PASSWORD
MYAPP_UPLOAD_KEY_PASSWORD=YOUR_KEY_PASSWORD
```

### Step 3: Update app.json for Production

Edit `app.json` and ensure these values are set:

```json
{
  "expo": {
    "name": "Traffic University",
    "slug": "traffic-university",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#ffffff"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#ffffff"
      },
      "package": "com.trafficuniversity.app",
      "versionCode": 1
    }
  }
}
```

### Step 4: Build APK

```bash
# Build release APK
eas build --platform android --type apk

# Or if using Expo CLI directly:
expo build:android -t apk
```

**Note:** This will upload your app to Expo's build servers and compile it. You'll receive a download link via email.

### Alternative: Build Locally with Android Studio

```bash
# Generate Android project
npx react-native-scripts eject

# Build APK
cd android
./gradlew assembleRelease

# APK will be at: android/app/build/outputs/apk/release/app-release.apk
```

---

## Part 3: Prepare for Google Play Console

### Step 1: Create Google Play Developer Account

1. Go to [Google Play Console](https://play.google.com/console)
2. Sign in with your Google account
3. Accept the terms and pay the $25 registration fee
4. Complete your developer profile

### Step 2: Create New App

1. Click "Create app"
2. Enter app name: **Traffic University**
3. Select default language: **English**
4. Select app type: **Games**
5. Select category: **Educational**
6. Indicate content rating: **Suitable for all ages**

### Step 3: Prepare App Information

**App Title:**
```
Traffic University - Rwanda Traffic Trivia
```

**Short Description (80 characters max):**
```
Learn Rwanda traffic rules through fun, timed trivia quizzes!
```

**Full Description:**
```
Traffic University is an engaging mobile trivia game designed to help drivers and traffic enthusiasts master Rwanda's traffic laws, road signs, and speed regulations.

Features:
✓ Three quiz categories: Traffic Laws, Road Signs, Speed Limits
✓ Timed 30-second questions for quick learning
✓ Streak bonuses for consecutive correct answers
✓ Global and friends-only leaderboards
✓ Detailed explanations for every answer
✓ Bilingual support: English & Kinyarwanda
✓ Admin panel to manage questions and content

Perfect for:
- New drivers preparing for licensing exams
- Experienced drivers staying updated on regulations
- Traffic safety enthusiasts
- Educational institutions

Learn, compete, and master Rwanda's traffic rules!
```

### Step 4: Upload Screenshots

Prepare 2-5 screenshots showing:
1. Home screen with categories
2. Quiz gameplay
3. Leaderboard
4. Answer explanation screen
5. Language toggle feature

**Screenshot Requirements:**
- Minimum 2, maximum 8 screenshots
- Minimum dimensions: 320x569 pixels
- Maximum dimensions: 3840x2160 pixels
- PNG or JPEG format

### Step 5: Upload App Icon

**Requirements:**
- 512x512 pixels
- PNG format
- No transparency
- Must be your logo (Traffic University logo)

### Step 6: Add Content Rating

Complete the content rating questionnaire:
- Violence: None
- Sexual content: None
- Profanity: None
- Alcohol/Tobacco: None
- Gambling: None
- Ads: Select if you plan to add ads

---

## Part 4: Upload APK to Google Play Console

### Step 1: Navigate to Release Section

1. In Google Play Console, go to your app
2. Click "Release" → "Production"
3. Click "Create new release"

### Step 2: Upload APK

1. Click "Upload" next to "APK"
2. Select your `app-release.apk` file
3. Wait for upload to complete
4. Review app details

### Step 3: Set Release Notes

```
Version 1.0.0 - Initial Release

Welcome to Traffic University! 🎓

This is the first release of Traffic University, featuring:
- 30 trivia questions across 3 categories
- Timed quiz gameplay with streak bonuses
- Global leaderboard rankings
- Bilingual support (English & Kinyarwanda)
- Admin panel for content management

Start learning Rwanda's traffic rules today!
```

### Step 4: Review and Submit

1. Review all information
2. Accept content policies
3. Click "Review release"
4. Click "Start rollout to Production"
5. Select rollout percentage (start with 5-10%, then increase)

---

## Part 5: Post-Launch

### Monitor Performance

1. Go to "Analytics" to track:
   - Downloads
   - Active users
   - Crashes
   - User ratings

### Update App

To release a new version:

1. Update version in `app.json`:
```json
"version": "1.0.1"
```

2. Increment versionCode:
```json
"versionCode": 2
```

3. Build new APK:
```bash
eas build --platform android --type apk
```

4. Upload to Google Play Console following steps in Part 4

---

## Troubleshooting

### APK Build Fails

**Solution:** Check that:
- All dependencies are installed: `npm install`
- Node version is 16+: `node --version`
- Android SDK is installed
- Internet connection is stable

### App Crashes on Launch

**Solution:**
- Check logcat: `adb logcat`
- Ensure all permissions are granted in `app.json`
- Test on multiple Android versions (API 21+)

### Upload Rejected by Google Play

**Common reasons:**
- APK not signed properly
- Minimum API level too low (use 21+)
- App icon missing or incorrect format
- Content rating incomplete

---

## Important Notes

1. **Keystore Security:** Keep your keystore file and passwords safe. You'll need them for all future updates.

2. **Version Management:** Always increment versionCode when releasing updates.

3. **Testing:** Test thoroughly on multiple Android devices before release.

4. **Privacy Policy:** Google Play requires a privacy policy. Create one at [privacypolicygenerator.info](https://www.privacypolicygenerator.info/)

5. **Review Time:** Initial app review takes 24-48 hours. Updates are typically faster.

---

## Quick Reference Commands

```bash
# Install dependencies
npm install

# Start development server
npm start

# Run on Android emulator
npm run android

# Build APK for release
eas build --platform android --type apk

# Check Android version
adb shell getprop ro.build.version.release

# View app logs
adb logcat
```

---

## Support Resources

- [Expo Documentation](https://docs.expo.dev/)
- [Google Play Console Help](https://support.google.com/googleplay/android-developer)
- [React Native Documentation](https://reactnative.dev/)
- [Android Development Guide](https://developer.android.com/guide)

---

## Next Steps

1. ✅ Set up local development environment
2. ✅ Test app on emulator
3. ✅ Create keystore file
4. ✅ Build release APK
5. ✅ Create Google Play Developer account
6. ✅ Prepare app information and screenshots
7. ✅ Upload APK to Google Play Console
8. ✅ Submit for review
9. ✅ Monitor performance and user feedback
10. ✅ Plan updates and improvements

Good luck with your Traffic University launch! 🚗📱
